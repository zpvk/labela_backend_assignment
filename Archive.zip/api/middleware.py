
from django.http import JsonResponse
from django.http import Http404

class JsonResponseOn404Middleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # This code will be executed for each request before reaching the view
        response = self.get_response(request)
        return response

    def process_exception(self, request, exception):
        # Handle exceptions here
        if isinstance(exception, Http404):
            return JsonResponse({'detail': 'Not found'}, status=404)
